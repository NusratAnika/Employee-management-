//Nusrat Jahan Anika
package vehicles_java;


public class cars extends properties{
    

    cars(String brand,String model,String transmission)
    {
        super.brand=brand;
        super.model=model;
        super.transmission=transmission;
        
    }
    void show()
    {
       
        System.out.println("The car's brand, model and transmussion are "+brand+", "+model+" and "+transmission+",respectively");
    }

}

