//Nusrat Jahan Anika
package vehicles_java;


public class buses extends properties {
    
    buses(String brand,String model,String transmission)
    {
        super.brand=brand;
        super.model=model;
        super.transmission=transmission;
        
    }
    void show()
    {
       
        System.out.println("The buse's brand, model and transmussion are "+brand+", "+model+" and "+transmission+",respectively");
    }
   
    
}
