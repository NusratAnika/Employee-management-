package vehicles_java;


public class Vehicles_java {

 
    public static void main(String[] args) {
        
        cars s1=new cars("BMW","X5","Auto");
        s1.show();

        buses s2=new buses("Volvo","D11","Auto");
        s2.show();

        trucks s3=new trucks("Hino","420 E5","Manual");
        s3.show();
        
        cars_function s4=new cars_function("3.0-liter BMW TwinPower Turbo inline 6-cylinder, 24-valve, 300-hp engine","Automatic control","Automatic control","Automatic control","Automatic control");
        s4.display();
        
        buses_function s5=new buses_function("5.1 litre, common rail, direct injection engine","Automatic control","Automatic control","Automatic control","Automatic control");
        s5.display();
        
        trucks_function s6=new trucks_function("Volvo D11 325-425 hp 1250-1550 lb-ft. engine","Automatic control","Automatic control","Manual control","Manual control");
        s6.display();

    }
    
}
