//Nusrat jahan Anika
package vehicles_java;

public class properties {
   
    String brand;
    String model;
    String transmission;
}
