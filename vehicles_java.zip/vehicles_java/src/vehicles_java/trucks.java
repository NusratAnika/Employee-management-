//Nusrat Jahan Anika
package vehicles_java;

public class trucks extends properties {
    
    trucks(String brand,String model,String transmission)
    {
        super.brand=brand;
        super.model=model;
        super.transmission=transmission;
        
    }
    void show()
    {
       
        System.out.println("The truck's brand, model and transmussion are "+brand+", "+model+" and "+transmission+",respectively");
    }
   
    
}
