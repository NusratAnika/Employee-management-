
package vehicles_java;

public class cars_function extends functions {
    
    cars_function (String engine,String gear,String brake,String light,String indicator)
    {
        super.engine=engine;
        super.gear=gear;
        super.brake=brake;
        super.light=light;
        super.indicator=indicator;
        
    }
    void display()
    {
       
        System.out.println("The car has "+engine+ ", gear: " +gear+ ", brake: "+brake+ ", light: "+light+ ", indicator: " +indicator);
    }
}
