//Nusrat jahan Anika
package vehicles_java;

public class functions {
    
    String engine;
    String gear;
    String brake;
    String light;
    String indicator;
    
}