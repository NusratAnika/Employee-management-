package quiz;

public class rhombas extends quadrilateral{
    rhombas(int base,int height)
    {
        this.base=base;
        this.height=height;
       
    }
    void area()
    {
         System.out.println("This rhombas area is:"+(this.base*this.height));
    }
}
