package quiz;

/**
 *
 * @author Student
 */
public class rectangle extends quadrilateral{
    rectangle(int height,int wide)
    {
        this.height=height;
        this.wide=wide;
        
    }
    void area()
    {
        System.out.println("This rectangle area is:"+(this.height*this.wide));
    }
}
