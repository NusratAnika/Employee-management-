package quiz;

public class quadrilateral {
    int lenght1,lenght2,lenght3,lenght4;
     int wide;
     int height;
     int base;
     int x;
      void setLength( int lenght1,int lenght2)
      {
          this.lenght1=lenght1;
          this.lenght2=lenght2;
          x=lenght1*lenght2;
      }
      void perameter(int lenght1,int lenght2,int lenght3,int lenght4)
      {
          this.lenght1=lenght1;
          this.lenght2=lenght2;
          this.lenght3=lenght3;
          this.lenght4=lenght4;
          System.out.println("This parameter is:"+(this.lenght1+this.lenght2+this.lenght3+this.lenght4));
      }
}
