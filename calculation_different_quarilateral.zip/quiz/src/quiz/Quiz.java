package quiz;

public class Quiz {

    public static void main(String[] args) {
        System.out.println("For rectangle ");
        rectangle r=new rectangle(10,12);
        r.area();
        r.perameter(12,23,12,34);
        
        
        System.out.println("\n\nFor Square ");
        square s=new square(10,12);
        s.area();
        s.perameter(8,9,7,10);
        
        
        System.out.println("\n\nFor rhombas ");
        rhombas rh=new rhombas(10,10);
        rh.area();
        rh.perameter(7,8,6,9);
        
        
        System.out.println("\n\nFor parallelogram ");
        parallelogram x=new parallelogram(12,10);
        x.area();
        x.perameter(10,11,12,13);
        
    }
    
}
