package quiz;

public class square extends quadrilateral{
    square (int a,int b)
    {
        this.setLength(a,b);
        
    }
    void area()
    {
        System.out.println("This square area is:"+x);
    }
}
