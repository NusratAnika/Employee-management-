

package employee_managemnet;
import java.io.*;
import java.util.Scanner;

public class advertisers extends employee_attribute {
    

    
    float bonus=0;
    float fined=0;
    advertisers(String name,String id,int age,String cell_number,String email,String address,float work_hours,float period,float salary, int leave,int pat_mat_leave)
    {
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.println("Enter a Salary: ");
        salary = reader.nextInt();
        System.out.println("Enter a age: ");
        work_hours = reader.nextInt();
        
        
        
        super.name=name;
        super.id=id;
        super.age=age;
        super.cell_number=cell_number;
        super.email=email;
        super.address=address;
        super.work_hours=work_hours;
        super.period=period;
        super.salary=salary;
        super.leave=leave;
        super.pat_mat_leave=pat_mat_leave;
        
        
    }
    void salary()
    {
         System.out.println(name+" has the salary of "+salary+" TK ");
    }
    void bonus()
    {
        if (period>=12)  // perid is in months
            System.out.println(name+" has the bounus of "+(float)(salary*.6)+" TK ");
        else 
        {
            System.out.println(name+" is not eligible for bonus");
        }
    }
    void fined()
    {
        if (work_hours>=8)
            System.out.println(name+" has no fined");
        else
        {
            fined=(float) (salary*.1);
            System.out.println(name+" has "+fined+" TK fined");
        }
    }
    
    void lev()
    {
        if (leave<=22)  // leave in days
            System.out.println(name+" has paid leave left "+(int)(22-leave)+ " days");
        else 
        {
            System.out.println(name+"is not paid for further leave");
        }
    }
     void pat_mat_lev()
    {
     
            System.out.println(name+" is not eligible for maternity/paternity leave");
       
    }
}
