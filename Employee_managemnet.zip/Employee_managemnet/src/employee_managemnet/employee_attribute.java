
package employee_managemnet;


public class employee_attribute {
    String name;
    String id;
    int age;
    String cell_number;
    String email;
    String address;
    float work_hours;
    float period;
    float salary;
    int leave;
    int pat_mat_leave;
}
