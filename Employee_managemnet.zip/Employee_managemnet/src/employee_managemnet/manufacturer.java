
package employee_managemnet;

public class manufacturer extends employee_attribute{
    float bonus=0;
    float fined=0;
    manufacturer(String name,String id,int age,String cell_number,String email,String address,float work_hours,float period,float salary, int leave,int pat_mat_leave)
    {
        super.name=name;
        super.id=id;
        super.age=age;
        super.cell_number=cell_number;
        super.email=email;
        super.address=address;
        super.work_hours=work_hours;
        super.period=period;
        super.salary=salary;
        super.leave=leave;
        super.pat_mat_leave=pat_mat_leave;
        
        
    }
    void salary()
    {
         System.out.println(name+" has the salary of "+salary+" TK ");
    }
    void bonus()
    {
        if (period>=12)  // perid is in months
            System.out.println(name+" has the bounus of "+(float)(salary*.5)+" TK ");
        else 
        {
            System.out.println(name+" is not eligible for bonus");
        }
    }
    void fined()
    {
        if (work_hours>=8)
            System.out.println(name+" has no fined");
        else
        {
            fined=(float) (salary*.1);
            System.out.println(name+" has "+fined+" TK fined");
        }
    }
    
    void lev()
    {
        if (leave<=18)  // leave in days
            System.out.println(name+" has paid leave left "+(int)(18-leave)+ " days");
        else 
        {
            System.out.println(name+"is not paid for further leave");
        }
    }
     void pat_mat_lev()
    {
     
            System.out.println(name+" is not eligible for maternity/paternity leave");
       
    }
}
