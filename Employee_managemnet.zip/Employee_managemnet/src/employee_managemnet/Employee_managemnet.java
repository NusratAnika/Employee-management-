//Nusrat Jahan Anika

package employee_managemnet;
import java.io.*;
import java.util.Scanner;


public class Employee_managemnet {

    public static void main(String[] args) {
        
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.println("Enter the users: ");
        int users = reader.nextInt();
        for( int i = 0; i < users; i++)
        { 
        manager sm1=new manager("Siam","171",30,"01816548921","siam@gmail.com","Narayangong",8,8,25000,7,0);
        sm1.salary();
        sm1.bonus();
        sm1.fined();
        sm1.lev();
        sm1.pat_mat_lev();
        System.out.println("\n");
      
        manager_female smf1=new manager_female("Tonni","181",30,"01716548921","tonni@gmail.com","Narayangong",7,20,30000,7,4);
        smf1.salary();
        smf1.bonus();
        smf1.fined();
        smf1.lev();
        smf1.pat_mat_lev();
        System.out.println("\n");

        advertisers ad=new advertisers("Shorna","151",40,"01996548921","shorna@gmail.com","Dhaka",8,11,20000,12,0);
        ad.salary();
        ad.bonus();
        ad.fined();
        ad.lev();
        ad.pat_mat_lev();
        System.out.println("\n");
        
        manufacturer man=new manufacturer("Big B","101",35,"01516548921","bigB@gmail.com","Narayangong",6,10,15000,7,0);
        man.salary();
        man.bonus();
        man.fined();
        man.lev();
        man.pat_mat_lev();
        System.out.println("\n");
        
        salesman sal=new salesman ("Han","141",27,"01675393721","han@gmail.com","Dhaka",6,7,1000,15,0);
        sal.salary();
        sal.bonus();
        sal.fined();
        sal.lev();
        sal.pat_mat_lev();
        System.out.println("\n");
        
    }
    
}
}