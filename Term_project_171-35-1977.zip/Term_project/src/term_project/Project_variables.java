package term_project;

public class Project_variables {
    
    String name;
    String id;
    String cell_number;
    String email;
    String address;
    float work_hours;
    float period;
    int salary;
    int age;
    int leave;
    int pat_mat_leave;
    int withdraw;
   
  
      
    }