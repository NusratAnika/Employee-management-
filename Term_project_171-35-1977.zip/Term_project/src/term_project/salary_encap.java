
package term_project;


public class salary_encap {
     private int VC_salary;
     private int Dean_salary;
     private int Pro_salary;
     private int Asso_pro_salary;
     private int Assi_pro_salary;
     private int Senior_lec_salary;
     private int Lec_salary;
     private int Cashier_salary;
     private int Staff_salary;
     public int getVC_salary(){
        return VC_salary;
    }      
    public int getDean_salary(){
        return Dean_salary;
    }      
    public int getPro_salary(){
        return Pro_salary;
    }      
    public int getAssi_pro_salary(){
        return Assi_pro_salary;
    }      
    public int getSenior_lec_salary(){
        return Senior_lec_salary;
    }      
    public int getlec_salary(){
        return Lec_salary;
    }      
    public int getAsso_pro_salary(){
        return Asso_pro_salary;
    }      
    public int getCashier_salary(){
        return Cashier_salary;
    }      
    public int getstaff_salary(){
        return Staff_salary;
    }      
     
    public void setVC_salary(int newValue){
        VC_salary = newValue;
    }
    public void setDean_salary(int newValue){
        Dean_salary = newValue;
    }
    public void setPro_salary(int newValue){
        Pro_salary = newValue;
    }
    public void setAsso_pro_salary(int newValue){
        Asso_pro_salary = newValue;
    }
    public void setAssi_pro_salary(int newValue){
        Assi_pro_salary = newValue;
    }
    public void setSenior_lec_salary(int newValue){
        Senior_lec_salary = newValue;
    }
    public void setLec_salary(int newValue){
        Lec_salary = newValue;
    }
    public void setCashier_salary(int newValue){
        Cashier_salary = newValue;
    }
    public void setStaff_salary(int newValue){
        Staff_salary = newValue;
    }
}


       