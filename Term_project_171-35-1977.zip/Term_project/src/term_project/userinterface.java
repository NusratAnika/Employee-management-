
package term_project;


public interface userinterface {
    public void work_hours();
    public void bonus();
    public  void leave();
}
