package assignment1;

public class nokia extends mobile{
    void imei()
    {
        System.out.println("This phone IMEI number 11002200330044");
    }
    void numOfSim()
    {
        System.out.println("This phone @ sim supported");
    }
    void processor()
    {
        System.out.println("This is nokia processor");
    }
    void RAM()
    {
        System.out.println("This phone have 4GB RAM");
    }
    void typeOfSiim()
    {
        System.out.println("This phone Supported nano sim");
    }
    void apps()
    {
        System.out.println("Can install application");
    }
    void photos()
    {
        System.out.println("Can take photos");
    }
}
