package assignment1;

import java.util.Scanner;

public class Assignment1 {

    public static void main(String[] args) {
        System.out.println("1.nokia\n2.Xiaomi\n3.huawei\n3.normal phone\nEnter your choice:");
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
        switch(x)
        {
            case 1:
            {
             nokia n1=new nokia();
             n1.call();
             n1.sms();
             n1.connect();
             n1.imei();
             n1.numOfSim();
             n1.processor();
             n1.RAM();
             n1.typeOfSiim();
             n1.apps();
             n1.photos();
             break;
            }
            case 2:
            {
             Xiaomi n1=new Xiaomi();
             n1.call();
             n1.sms();
             n1.connect();
             n1.imei();
             n1.numOfSim();
             n1.processor();
             n1.RAM();
             n1.typeOfSiim();
             n1.apps();
             n1.photos();
             break;
            }
            case 3:
            {
             huawei n1=new huawei();
             n1.call();
             n1.sms();
             n1.connect();
             n1.imei();
             n1.numOfSim();
             n1.processor();
             n1.RAM();
             n1.typeOfSiim();
             n1.apps();
             n1.photos();   
             break;
            }            
            case 4:
            {
             normal n1=new normal();
             n1.call();
             n1.sms();
             n1.connect();
             n1.imei();
             n1.numOfSim();
             n1.processor();
             n1.RAM();
             n1.typeOfSiim();
             n1.apps();
             n1.photos();
             break;
            }
    }
        
    }
    
}
