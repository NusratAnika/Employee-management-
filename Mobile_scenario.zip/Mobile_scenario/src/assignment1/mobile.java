package assignment1;
public class mobile {
    void call()
    {
        System.out.println("This Phone Can making call and receiving call");
    }
    void sms()
    {
        System.out.println("This Phone Can sending and receiving text message");
    }
    void connect()
    {
        System.out.println("This Phone Can connecting to bluetooth and wifi");
    }
    
}
